<?php dynamic_sidebar( 'post-sidebar' ); ?>
