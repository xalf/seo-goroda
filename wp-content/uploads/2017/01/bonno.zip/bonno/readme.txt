Theme Name: Bonno
Theme URI: http://bonno.aisconverse.com
Author: the Aisconverse team
Author URI: http://aisconverse.com
Description: A lightweight and responsive WordPress theme designed with simplicity and flexibility in mind. Bonno offers clean look and useful theme customizations, good shortcodes collection and a great tool to introduce you or your company to the world.
Version: 1.0
License: GNU General Public License
License URI: http://www.gnu.org/copyleft/gpl.html
Tags: white, light, left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, responsive-layout, fluid-layout, custom-colors, editor-style, post-formats, sticky-post, theme-options, translation-ready
Text Domain: bonno 